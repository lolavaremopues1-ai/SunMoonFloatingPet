# Sun & Moon – Floating Companions (Android)

Proyecto Android nativo en Kotlin. Muestra dos mascotas pixel art (Sun y Moon) en ventanas flotantes sobre otras aplicaciones, con movimiento autónomo, arrastre táctil y cambio de expresión al tocarlas.

## Requisitos
- Android Studio Ladybug o posterior
- JDK 17
- Android SDK 35
- Un teléfono Android 8.0 (API 26) o posterior

## Compilar e instalar
1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice el proyecto.
3. Conecta tu teléfono con depuración USB o crea un APK desde **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Instala el APK.
5. Abre **Sun & Moon** y pulsa **Dejar que caminen por mi pantalla**.
6. Android abrirá el ajuste de permiso «Mostrar sobre otras aplicaciones». Actívalo y vuelve a la app.
7. Para detenerlos, usa el botón de la app o la acción **Detener** de la notificación persistente.

## Controles
- Arrastrar: mueve a cada personaje.
- Tocar sin arrastrar: cambia su expresión.
- Botón de la app / notificación: detiene ambas mascotas.

## Notas
- El servicio usa el tipo `specialUse` de Android 14+ y declara el subtipo de uso en el manifiesto.
- La disponibilidad de ventanas flotantes y las restricciones de batería pueden variar según la marca del teléfono. Algunos fabricantes pueden detener servicios en segundo plano; si ocurre, permite que la app se ejecute sin optimización de batería.
- Este proyecto contiene sprites pixel art originales inspirados en los arquetipos visuales de Sun y Moon. No incluye recursos oficiales de Five Nights at Freddy's.
- No se ha generado un APK compilado en este entorno porque no hay Android SDK/Gradle instalado. El proyecto fuente está listo para abrirse y compilarse en Android Studio.
