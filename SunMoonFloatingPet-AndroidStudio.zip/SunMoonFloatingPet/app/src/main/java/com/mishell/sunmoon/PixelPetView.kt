package com.mishell.sunmoon

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.random.Random

internal enum class PetKind { SUN, MOON }

internal class PixelPetView(
    context: Context,
    private val kind: PetKind,
    private val viewWidth: Int,
    private val viewHeight: Int
) : View(context) {
    private val paint = Paint().apply { isAntiAlias = false; style = Paint.Style.FILL }
    var petX = 0
    var petY = 0
    var onPositionChanged: ((Int, Int) -> Unit)? = null
    private var directionX = if (kind == PetKind.SUN) 1 else -1
    private var directionY = if (kind == PetKind.SUN) 1 else -1
    private var frame = 0
    private var mood = 0
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var moved = false

    fun advance(maxX: Int, maxY: Int) {
        frame++
        if (frame % 38 == 0 && Random.nextFloat() < 0.45f) {
            directionX = if (Random.nextBoolean()) 1 else -1
            directionY = if (Random.nextBoolean()) 1 else -1
        }
        val pace = if (kind == PetKind.SUN) 5 else 4
        petX += directionX * pace
        petY += directionY * (pace / 2 + 1)
        if (petX <= 0 || petX >= maxX) directionX *= -1
        if (petY <= 0 || petY >= maxY) directionY *= -1
        petX = petX.coerceIn(0, maxX)
        petY = petY.coerceIn(0, maxY)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cell = width / 16f
        canvas.save()
        canvas.scale(cell, height / 24f)
        if (kind == PetKind.SUN) drawSun(canvas) else drawMoon(canvas)
        canvas.restore()
    }

    private fun pixel(c: Canvas, x: Int, y: Int, color: Int, w: Int = 1, h: Int = 1) {
        paint.color = color
        c.drawRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat(), paint)
    }

    private fun drawSun(c: Canvas) {
        val outline = 0xFFB85B27.toInt(); val gold = 0xFFFFC928.toInt(); val light = 0xFFFFE56B.toInt()
        val orange = 0xFFF49A25.toInt(); val dark = 0xFF49352F.toInt(); val white = 0xFFFFF4D6.toInt()
        // Ray crown and side rays
        pixel(c, 7, 0, orange, 2, 2); pixel(c, 3, 1, gold, 2, 2); pixel(c, 11, 1, gold, 2, 2)
        pixel(c, 1, 4, orange, 2, 2); pixel(c, 13, 4, orange, 2, 2)
        pixel(c, 0, 8, gold, 2, 2); pixel(c, 14, 8, gold, 2, 2)
        pixel(c, 2, 12, gold, 2, 2); pixel(c, 12, 12, gold, 2, 2)
        // Head outline
        pixel(c, 5, 2, outline, 6, 1); pixel(c, 3, 3, outline, 10, 1)
        pixel(c, 2, 4, outline, 12, 7); pixel(c, 3, 11, outline, 10, 2)
        pixel(c, 5, 13, outline, 6, 1)
        // Face
        pixel(c, 5, 3, gold, 6, 9); pixel(c, 4, 5, gold, 8, 6); pixel(c, 6, 4, light, 4, 2)
        pixel(c, 5, 7, dark, 2, if (mood == 1) 1 else 2); pixel(c, 9, 7, dark, 2, if (mood == 1) 1 else 2)
        if (mood == 2) { pixel(c, 6, 10, dark, 4, 1); pixel(c, 6, 9, dark, 1, 1); pixel(c, 9, 9, dark, 1, 1) }
        else { pixel(c, 6, 10, dark, 4, 1); pixel(c, 7, 11, dark, 2, 1) }
        pixel(c, 3, 9, orange, 1, 2); pixel(c, 12, 9, orange, 1, 2)
        // Neck, little jester body and collar
        pixel(c, 7, 14, outline, 2, 2); pixel(c, 5, 15, 0xFFDFE6E8.toInt(), 6, 1)
        pixel(c, 4, 16, outline, 8, 1); pixel(c, 5, 17, 0xFFE9E5D8.toInt(), 6, 4)
        pixel(c, 4, 18, outline, 1, 3); pixel(c, 11, 18, outline, 1, 3)
        pixel(c, 6, 18, 0xFFB8D7D0.toInt(), 4, 2)
        // Animated feet and hands
        val step = if (frame / 5 % 2 == 0) 0 else 1
        pixel(c, 2, 17 + step, gold, 2, 2); pixel(c, 12, 17 + (1 - step), gold, 2, 2)
        pixel(c, 5, 21 + step, outline, 2, 2); pixel(c, 9, 21 + (1 - step), outline, 2, 2)
        pixel(c, 4, 23, dark, 3, 1); pixel(c, 9, 23, dark, 3, 1)
        if (mood == 1) { pixel(c, 6, 7, white, 1, 1); pixel(c, 10, 7, white, 1, 1) }
    }

    private fun drawMoon(c: Canvas) {
        val outline = 0xFF26365D.toInt(); val blue = 0xFF526DB4.toInt(); val pale = 0xFFDCE6FF.toInt()
        val silver = 0xFF9FB7E8.toInt(); val dark = 0xFF18233E.toInt(); val white = 0xFFFFFFFF.toInt()
        // Crescent cap silhouette
        pixel(c, 6, 0, outline, 5, 1); pixel(c, 4, 1, outline, 8, 1); pixel(c, 3, 2, outline, 9, 2)
        pixel(c, 2, 4, outline, 10, 7); pixel(c, 3, 11, outline, 8, 2)
        pixel(c, 5, 13, outline, 5, 1)
        // pale face crescent
        pixel(c, 6, 1, blue, 5, 1); pixel(c, 4, 2, blue, 7, 2); pixel(c, 3, 4, blue, 7, 7)
        pixel(c, 4, 11, blue, 6, 1); pixel(c, 6, 12, blue, 3, 1)
        pixel(c, 7, 3, pale, 3, 1); pixel(c, 5, 4, pale, 3, 5); pixel(c, 4, 7, pale, 3, 4)
        // eyes and sleepy mouth
        pixel(c, 5, 7, dark, 2, if (mood == 1) 1 else 2); pixel(c, 8, 7, dark, 2, if (mood == 1) 1 else 2)
        if (mood == 2) { pixel(c, 6, 10, dark, 3, 1) } else { pixel(c, 6, 10, dark, 3, 1); pixel(c, 7, 11, dark, 1, 1) }
        pixel(c, 3, 9, silver, 1, 2)
        // scarf and night robe
        pixel(c, 7, 14, outline, 2, 2); pixel(c, 5, 15, silver, 6, 1)
        pixel(c, 4, 16, outline, 8, 1); pixel(c, 5, 17, blue, 6, 4)
        pixel(c, 4, 18, outline, 1, 3); pixel(c, 11, 18, outline, 1, 3)
        pixel(c, 6, 18, pale, 1, 2); pixel(c, 9, 18, pale, 1, 2)
        val step = if (frame / 6 % 2 == 0) 0 else 1
        pixel(c, 2, 17 + step, blue, 2, 2); pixel(c, 12, 17 + (1 - step), blue, 2, 2)
        pixel(c, 5, 21 + step, outline, 2, 2); pixel(c, 9, 21 + (1 - step), outline, 2, 2)
        pixel(c, 4, 23, dark, 3, 1); pixel(c, 9, 23, dark, 3, 1)
        if (mood == 1) { pixel(c, 5, 7, white, 1, 1); pixel(c, 9, 7, white, 1, 1) }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.rawX; lastTouchY = event.rawY; moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - lastTouchX).toInt(); val dy = (event.rawY - lastTouchY).toInt()
                if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 2) moved = true
                if (moved) onPositionChanged?.invoke(dx, dy)
                lastTouchX = event.rawX; lastTouchY = event.rawY
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) { mood = (mood + 1) % 3; invalidate() }
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
