package com.mishell.sunmoon

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager

class PetOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private val pets = mutableListOf<PixelPetView>()
    private val params = mutableMapOf<PixelPetView, WindowManager.LayoutParams>()
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var running = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) addPets()
        return START_STICKY
    }

    private fun addPets() {
        running = true
        val metrics = resources.displayMetrics
        val width = (metrics.widthPixels * 0.19f).toInt().coerceIn(112, 156)
        val height = (width * 1.42f).toInt()
        val y1 = (metrics.heightPixels * 0.38f).toInt()
        val y2 = (metrics.heightPixels * 0.58f).toInt()
        listOf(PetKind.SUN, PetKind.MOON).forEachIndexed { index, kind ->
            val view = PixelPetView(this, kind, width, height)
            val p = WindowManager.LayoutParams(
                width, height,
                if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = if (index == 0) 36 else (metrics.widthPixels - width - 36).coerceAtLeast(0)
                y = if (index == 0) y1 else y2
            }
            view.onPositionChanged = { dx, dy ->
                view.petX = (view.petX + dx).coerceIn(0, (metrics.widthPixels - width).coerceAtLeast(0))
                view.petY = (view.petY + dy).coerceIn(0, (metrics.heightPixels - height).coerceAtLeast(0))
                p.x = view.petX
                p.y = view.petY
                try { windowManager.updateViewLayout(view, p) } catch (_: Exception) { }
            }
            pets.add(view)
            params[view] = p
            windowManager.addView(view, p)
        }
        handler.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val metrics = resources.displayMetrics
            pets.forEach { pet ->
                val p = params[pet] ?: return@forEach
                val maxX = (metrics.widthPixels - p.width).coerceAtLeast(0)
                val maxY = (metrics.heightPixels - p.height).coerceAtLeast(0)
                pet.advance(maxX, maxY)
                p.x = pet.petX.coerceIn(0, maxX)
                p.y = pet.petY.coerceIn(0, maxY)
                try { windowManager.updateViewLayout(pet, p) } catch (_: Exception) { }
                pet.invalidate()
            }
            handler.postDelayed(this, 90L)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Sun & Moon", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Control de las mascotas flotantes"
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, PetOverlayService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Sun & Moon están caminando")
            .setContentText("Toca «Detener» para guardarlos")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Detener", pending).build())
            .build()
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        pets.forEach { try { windowManager.removeView(it) } catch (_: Exception) { } }
        pets.clear(); params.clear()
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.mishell.sunmoon.START"
        const val ACTION_STOP = "com.mishell.sunmoon.STOP"
        private const val CHANNEL_ID = "sun_moon_pets"
        private const val NOTIFICATION_ID = 27
    }
}
