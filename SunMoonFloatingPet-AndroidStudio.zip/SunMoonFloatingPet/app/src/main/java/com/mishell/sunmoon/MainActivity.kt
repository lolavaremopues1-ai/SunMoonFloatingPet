package com.mishell.sunmoon

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestOverlay = 4101
    private val requestNotifications = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        askNotificationPermissionIfNeeded()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFFFFF8E8.toInt())
        }
        val title = TextView(this).apply {
            text = "SUN  &  MOON"
            textSize = 30f
            setTextColor(0xFF473A35.toInt())
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "Tus pequeños compañeros pixel art\nsiempre cerca de ti."
            textSize = 16f
            setTextColor(0xFF75665C.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 30)
        }
        val start = Button(this).apply {
            text = "Dejar que caminen por mi pantalla"
            textSize = 15f
            setOnClickListener { startPets() }
        }
        val stop = Button(this).apply {
            text = "Guardar mascotas"
            setOnClickListener {
                stopService(Intent(this@MainActivity, PetOverlayService::class.java))
                Toast.makeText(this@MainActivity, "Sun y Moon se fueron a descansar.", Toast.LENGTH_SHORT).show()
            }
        }
        val note = TextView(this).apply {
            text = "Primero concede el permiso «Mostrar sobre otras aplicaciones».\n\nToca a cada personaje para cambiar su expresión y arrástralo para moverlo."
            textSize = 13f
            setTextColor(0xFF8A7B70.toInt())
            gravity = Gravity.CENTER
            setPadding(4, 26, 4, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(start, LinearLayout.LayoutParams(-1, -2))
        root.addView(stop, LinearLayout.LayoutParams(-1, -2))
        root.addView(note)
        setContentView(root)
    }

    private fun startPets() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, requestOverlay)
            return
        }
        val intent = Intent(this, PetOverlayService::class.java).setAction(PetOverlayService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "¡Sun y Moon están sueltos!", Toast.LENGTH_SHORT).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay && Settings.canDrawOverlays(this)) startPets()
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestNotifications)
        }
    }
}
